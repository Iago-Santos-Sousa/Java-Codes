<?php
require_once("url.php");
require_once("conexao.php");
require_once("../models/User.php");
require_once("../models/Message.php");
require_once("../dao/userDao.php");

$message = new Message($BASE_URL);
$userDao = new UserDao($conn, $BASE_URL);

$type = filter_input(INPUT_POST, "type");

if($type === "register") {
    $nome = filter_input(INPUT_POST, "name");
    $ultimonome = filter_input(INPUT_POST, "lastname");
    $email = filter_input(INPUT_POST, "email");
    $password = filter_input(INPUT_POST, "password");
    $confirmpassword = filter_input(INPUT_POST, "confirmpassword");
}

if($nome && $ultimonome && $email && $password) {
    if($password != $confirmpassword) {
        $message->setMessage("As senhas não são iguais", "error", "back");

    } elseif($userDao->findByEmail($email === false)) {
        echo "Nenhum usuário encontrado!";

        $user = new User();
        //cria token

        $userToken = $user->generateToken();
        $finalPassword = $user->generatePassword($password);
        $user->name = $nome;
        $user->lastname = $ultimonome;
        $user->email = $email;
        $user->password = $finalPassword;
        $user->token = $userToken;
        $path = true;
        $userDao->create($user, $auth);
    } else {
        // $message->setMessage("Já existe um email cadastrado na base", "error", "back");
    }

}else {
    // $message-setMessage("por favor preencha todos os campos", "error", "back");
}










?>