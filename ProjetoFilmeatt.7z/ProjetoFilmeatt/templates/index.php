<?php
include_once("header.php");
?>
<h1>Página principal</h1>
<?php
include_once("footer.php");
?>
